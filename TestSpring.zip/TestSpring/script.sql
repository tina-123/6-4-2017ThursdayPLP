drop table MOBILEDATA;

create table mobileData(mob_id number(6) primary key, 
													mob_name varchar2(30),
													mob_brand varchar2(20),
													mob_price number(10));
													
insert into MOBILEDATA values(1001,'A','LG',20000);

insert into MOBILEDATA values(1002,'B','Apple',30000);

insert into MOBILEDATA values(1003,'C','Micromax',10000);

select * from MOBILEDATA;

create sequence mob_seq_id start with 1000;

select mob_seq_id.nextval from dual;

update MOBILEDATA set mob_name='Sony' where mob_id='1003';

==============================================================================================================


create table USER_HBMS(USER_ID number primary key, PASSWORD varchar2(20), ROLE varchar(10), 
USER_NAME varchar2(20), MOBILE_NO varchar2(10), PHONE varchar2(10), ADDRESS varchar2(50), EMAIL  varchar2(30));

create sequence USER_HBMS_SEQ start with 1000

drop table USER_HBMS

drop sequence User_HBMS_SEQ

select * from USER_HBMS





create table ROOM_HBMS(HOTEL_ID number,ROOM_ID number primary key,ROOM_NO varchar2(3),ROOM_TYPE varchar2(20),
PER_NIGHT_RATE number(6,2),AVAILABILITY char,foreign key(HOTEL_ID)References HOTEL_HBMS(HOTEL_ID));

create sequence  ROOM_HBMS_SEQ start with 1000

drop table ROOM_HBMS cascade constraint

drop sequence ROOM_HBMS_SEQ

select * from ROOM_HBMS



create table HOTEL_HBMS(HOTEL_ID number primary key, CITY varchar2(10), HOTEL_NAME varchar2(20),ADDRESS varchar2(50), 
DESCRIPTION varchar2(50), AVG_RATE_PER_NIGHT number(10,2),PHONE_NO1 varchar2(10), PHONE_NO2 varchar2(10), 
RATING varchar2(5), EMAIL varchar2(50), FAX varchar2(15));

create sequence HOTEL_HBMS_SEQ start with 1000

drop table HOTEL_HBMS 

drop sequence HOTEL_HBMS_SEQ

select * from HOTEL_HBMS

delete from HOTEL_HBMS where CITY='Mumbai' 



create table BOOKING_HBMS(BOOKING_ID number primary key, ROOM_ID number,USER_ID number,BOOKED_FROM date,
BOOKED_TO date, NO_OF_ADULTS number, NO_OF_CHILDREN number, AMOUNT number(6,2),foreign key(ROOM_ID) references ROOM_HBMS(ROOM_ID));

create sequence BOOKING_HBMS_SEQ start with 100

drop table BOOKING_HBMS

drop sequence BOOKING_HBMS_SEQ

select * from BOOKING_HBMS

insert into BOOKING_HBMS values(101,50000,50001,'04-Apr-2017','05-Apr-2017',2,2,5000)
