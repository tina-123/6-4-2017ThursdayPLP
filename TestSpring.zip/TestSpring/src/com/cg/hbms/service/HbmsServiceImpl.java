package com.cg.hbms.service;

 

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.hbms.dao.IHbmsDao;
import com.cg.hbms.dto.BookingDetails;
import com.cg.hbms.dto.Hotels;
import com.cg.hbms.dto.RoomDetails;
import com.cg.hbms.dto.Users;



@Service("hbmsService")
@Transactional
public class HbmsServiceImpl implements IHbmsService {

	@Autowired
	IHbmsDao hbmsDao;
	
	@Override
	public int addHotel(Hotels hotel)
	{
		return hbmsDao.addHotel(hotel);
	}

	@Override
	public int addUser(Users user) 
	{
		return hbmsDao.addUser(user);
	}

	@Override
	public int addRoom(RoomDetails room) 
	{
		return hbmsDao.addRoom(room);
	}

	@Override
	public int addBooking(BookingDetails book) 
	{
		return hbmsDao.addBooking(book);
	}

	@Override
	public List<Hotels> showHotels() 
	{
		return hbmsDao.showHotels();
	}

	@Override
	public List<RoomDetails> showRooms() 
	{
		return hbmsDao.showRooms();
	}

	@Override
	public List<Users> showUsers() 
	{
		return hbmsDao.showUsers();
	}

	@Override
	public List<BookingDetails> showBookings() 
	{
		return hbmsDao.showBookings();
	}

	@Override
	public List<Hotels> searchHotels(String city) {
		
		return hbmsDao.searchHotels(city);
	}

	@Override
	public List<RoomDetails> searchRooms(String roomType) {
		
		return hbmsDao.searchRooms(roomType);
	}

	@Override
	public void removeHotel(int hotelId) {
		hbmsDao.removeHotel(hotelId);
		
	}

	@Override
	public void removeRoom(int roomId)
	{
		hbmsDao.removeRoom(roomId);
		
	}

	@Override
	public List<Users> searchUsers(int userId) {
		
		return hbmsDao.searchUsers(userId);
	}

	@Override
	public void updateHotel(Hotels hotel) 
	{
		hbmsDao.updateHotel(hotel);
	}

	@Override
	public Hotels searchHotelsId(int id) 
	{
		return hbmsDao.searchHotelsId(id);
	}

	@Override
	public RoomDetails searchRoomsId(int id) 
	{
		return hbmsDao.searchRoomsId(id);
	}

	@Override
	public void updateRoom(RoomDetails room) 
	{
		hbmsDao.updateRoom(room);
	}

	@Override
	public String getRole(String name, String pass)
	{
		
		return hbmsDao.getRole(name, pass);
	}

	@Override
	public void removeBooking(int bookingId) 
	{
		hbmsDao.removeBooking(bookingId);
		
	}

	@Override
	public List<BookingDetails> viewMyBooking(int userId)
	{
		
		return hbmsDao.viewMyBooking(userId);
	}

}
